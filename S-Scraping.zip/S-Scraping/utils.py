keys = {
    #PERMANENT INFO
    'email' : '------',
    'password' : '----',

    }
