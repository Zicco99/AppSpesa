keys = {
    #PERMANENT INFO
    'email' : 'chilledpanda@protonmail.com',
    'password' : 'Popcorn99!',

    }